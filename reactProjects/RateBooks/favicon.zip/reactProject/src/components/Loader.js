const Loader = ()=>{
    return(
        <div className = "d-flex justify-content-center" style ={{marginTop:'50px'}}>
            <div className="spinner-grow text-primary me-2" role="status"></div>
            <div className="spinner-grow text-primary me-2" role="status"></div>
            <div className="spinner-grow text-primary me-2" role="status"></div>
        </div>
    )
}

export default Loader