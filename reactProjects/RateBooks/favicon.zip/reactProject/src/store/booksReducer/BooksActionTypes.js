const Type = {
    addBook: 'books/ add bok to books',
    setBooks: 'books/ rewrite booksArr',
    getAllBooks: 'books/get books from local storage'
}

export default Type